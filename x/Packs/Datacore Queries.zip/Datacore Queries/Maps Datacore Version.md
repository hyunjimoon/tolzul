---
up:
  - "[[Home Pro]]"
in:
  - "[[Collections]]"
  - "[[Maps]]"
related:
  - "[[+ About Datacore Queries]]"
created: 2024-12-26
rank: 5.5
obsidianUIMode: preview
mapState:
  - 🟨
---
> [!video]- Related video lessons
> - [How to Use the Maps Collection](https://community.linkingyourthinking.com/c/ideaverse-pro/sections/146181/lessons/513557)

This note collects all notes where the `in` property says `Maps`.

> [!planet]- # Atlas Maps

> [!map]+ #### Maps that are "Collections"
> "Collections" are maps that ***auto-collect notes that link to it*** using the `in:` property so that they can be ***dynamically displayed***.
> ```datacorejsx
> const { AllCollectionsQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <AllCollectionsQuery/>;
> }
> ```

> [!map]- #### Map that are "Views"
> "Views" are maps whose main purpose is ***to show auto-updating, dynamic views of custom searches.*** 
> ```datacorejsx
> const { AllViewsQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <AllViewsQuery/>;
> }
> ```

---

> [!map]- ## All the maps by rank
> All maps where the `in` property says `Maps`.
> ```datacorejsx
> const { AllMapsByRankQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <AllMapsByRankQuery/>;
> }
> ```

> [!map]- ## All the maps by state
> All maps sorted by `mapState` to help you see which need some work
> ```datacorejsx
> const { AllMapsByStateQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <AllMapsByStateQuery/>;
> }
> ```

> [!zap]+ # My favorite sensemaking maps
> All the maps in the ideaverse where the `in` property has `Maps` and the rank is above `3.5`
>  ```datacorejsx
> const { FavoriteSensemakingMapsQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <FavoriteSensemakingMapsQuery/>;
> }
> ```

> [!wand]- #### All maps by total links
> This query sorts all maps based on their total links (backlinks + outgoing links).
> Useful for seeing which maps we've done the most exploration and sensemaking in.
> ```datacorejsx
> const { AllMapsByTotalLinksQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");
> 
> return function View() {
>     return <AllMapsByTotalLinksQuery/>;
> }
> ```
