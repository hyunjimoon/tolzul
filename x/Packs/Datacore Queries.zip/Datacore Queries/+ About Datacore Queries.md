---
version: "1.0"
---


> [!WARNING] Early in development
> This plugin isn't even published in the official Obsidian store so there's still a long ways to go. This is for people who are willing to experiment and get a taste of what's possible. Expect bugs and getting your hands dirty.

This note explains how to set up and use this pack for using Datacore queries in your vault.

As of now, this pack
[[Maps Datacore Version]]
[[Sources Datacore Version]]

## How is this installed?
Please see the external documentation for the most up to date version.

### Set up in Obsidian

Since Datacore is not in the official Obsidian plugins store, you must use the BRAT Obsidian plugin.

1. Go to `Settings -> Community Plugins -> Browse` , search for `BRAT` plugin
2. Download, and enable it.
3. Go to the plugin settings, and under the `Beta plugin list` section, click on the `Add beta plugin` button.
4. Paste in the URL of the GitHub repository, [https://github.com/blacksmithgu/datacore](https://github.com/blacksmithgu/datacore) , and click `Add Plugin` and make sure `Enable after installing the plugin` is checked.

Note that every time Obsidian is opened or restarted, it will take some time for Datacore to index all your files. Although it takes longer than Dataview, this initial preparation allows for 50x faster query load times during actual usage.
## How do they work?
The queries are stored as code, which we can render using code blocks. 
### What are some limitations?
#### Interactable elements for queries in callouts only work on preview mode
If you try clicking on any interactable query elements while viewing the note in edit mode, then it will instead start editing the callout.

This applies for things like:
- Using the bottom page navigation
- Clicking on a header to change the column sorting type

#### Clicking on row headers to sort in callouts only works on preview mode
If you try clicking on a header row of a query while viewing the note in edit mode, then it will instead start editing the callout.
## How can I modify them?
### Page size
By default, it is set to 25. If you're experiencing performance issues, you can change the amount of results shown in the table in the plugin settings. However, we suggest having higher numbers if you would like to click on the table headers to modify the sorting criteria since it will only sort the notes currently shown.
### Other
Since this plugin is in early development, customizing queries requires you to work with the programming language JavaScript.

All files are stored in the `x/Packs/Datacore Queries` folder, but JS files are hidden in Obsidian, so you must view them using your file explorer.

Then, you can open the file using a text application like `Notepad++` or a code editor like `Visual Studio Code` (recommended).

For organization, each Datacore query map has its queries in its own file.

Each query has its own function and has three main things you may want to edit:
- `columns`, to modify the labels or values of columns
- `pages`, to change the query logic for choosing which files to find
- `sortedPages`, to change the way the files are sorted

If you want to make your own, you must create a new function and then add it to the `return` statement at the end of the list.

## How can I use them in other notes?
You can copy the code blocks inside the callouts to use these queries in other places. Just be sure that the file path and name of the function being imported is correct:

````
```datacorejsx
// make sure file path is the correct one where the query is stored (ex. `maps.jsx`)
const { AllCollectionsQuery } = await dc.require("x/Packs/Datacore Queries/maps.jsx");

// also make sure name of the query (ex. AllCollectionsQuery) is correct here
return function View() {
    return <AllCollectionsQuery/>;
}
```
````
## How can I learn more?
I suggest going to their documentation https://blacksmithgu.github.io/datacore/code-views#displaying-your-data, but the real magic and tinkering happens in their [Dataview and Datacore discord server](https://discord.gg/KwZUX4BYba).
