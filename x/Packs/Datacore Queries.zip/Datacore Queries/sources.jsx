const { multiSort } = await dc.require("x/Packs/Datacore Queries/sort.js");

function AllBooksQuery() {
  const columns = [
    { id: "Year", value: (page) => page.value("year") },
    { id: "Cover", value: (page) => `![|60](${page.value("image")})` },
    { id: "Title", value: (page) => page.$link },
    { id: "Author", value: (page) => page.value("by").join(", ") },
    { id: "YearXP", value: (page) => page.value("yearXP") },
    { id: "Rating", value: (page) => page.value("rating") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Books]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rating", sortOrder: "desc", type: "number" },
          { fieldName: "yearXP", sortOrder: "asc", type: "date" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllMoviesQuery() {
  const columns = [
    { id: "Year", value: (page) => page.value("year") },
    { id: "Poster", value: (page) => `![|60](${page.value("image")})` },
    { id: "Title", value: (page) => page.$link },
    { id: "Author", value: (page) => page.value("rating") },
    { id: "YearXP", value: (page) => page.value("yearXP") },
    { id: "YearXPL", value: (page) => page.value("yearXPL") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Movies]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rating", sortOrder: "desc", type: "number" },
          { fieldName: "yearXP", sortOrder: "desc", type: "date" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllSeriesQuery() {
  const columns = [
    { id: "Years", value: (page) => page.value("years") },
    { id: "Poster", value: (page) => `![|60](${page.value("image")})` },
    { id: "Title", value: (page) => page.$link },
    { id: "Author", value: (page) => page.value("rating") },
    { id: "YearXP", value: (page) => page.value("yearXP") },
    { id: "YearXPL", value: (page) => page.value("yearXPL") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Series]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rating", sortOrder: "desc", type: "number" },
          { fieldName: "yearXP", sortOrder: "asc", type: "date" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllSourcesQuery() {
  const columns = [
    { id: "Year", value: (page) => page.value("year") },
    { id: "Source", value: (page) => page.$link },
    { id: "Tags", value: (page) => page.$tags.join("\n") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Sources]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([{ fieldName: "year", sortOrder: "asc", type: "number" }])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

return { AllSourcesQuery, AllBooksQuery, AllMoviesQuery, AllSeriesQuery };
