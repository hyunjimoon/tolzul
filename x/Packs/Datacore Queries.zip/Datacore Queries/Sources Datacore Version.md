---
up:
  - "[[Home Pro]]"
in:
  - "[[Collections]]"
  - "[[Views]]"
  - "[[Maps]]"
related:
  - "[[+ About Datacore Queries]]"
created: 2024-12-26
rank: 3
mapState:
  - 🟨
---

> [!book]- ## Books
> [[Books]] sorted by `Ratings` & `YearXP`. 
> ```datacorejsx
> const { AllBooksQuery } = await dc.require("x/Packs/Datacore Queries/sources.jsx");
> 
> return function View() {
>     return <AllBooksQuery/>;
> }
> ```

> [!video]+ ## Movies
> [[Movies]] sorted by Ratings, with Covers & YearXP
> 
> ```datacorejsx
> const { AllMoviesQuery } = await dc.require("x/Packs/Datacore Queries/sources.jsx");
> 
> return function View() {
>     return <AllMoviesQuery/>;
> }
> ```

> [!Waves]+ ## Series
> [[Series]] sorted by Ratings, with Covers & YearXP
> 
> ```datacorejsx
> const { AllSeriesQuery } = await dc.require("x/Packs/Datacore Queries/sources.jsx");
> 
> return function View() {
>     return <AllSeriesQuery/>;
> }
> ```

> [!Script]- ## ALL SOURCES by `in` property
> This is a simple data view collecting any note where the `in:` property links to `[[Sources]]`. The default view is sorted by year, to give a chronological view of all sources. This can be nice to see them in a different context.
> 
> ```datacorejsx
> const { AllSourcesQuery } = await dc.require("x/Packs/Datacore Queries/sources.jsx");
> 
> return function View() {
>     return <AllSourcesQuery/>;
> }
> ```
