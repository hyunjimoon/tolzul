const { multiSort } = await dc.require("x/Packs/Datacore Queries/sort.js");

function AllMapsByTotalLinksQuery() {
  const current = dc.useCurrentFile();
  // TODO: find a way to maybe store this in the pages themselves, to allow for multiSort function usage.
  // Another option is to just pass in the noteStats object to the multiSort function.
  const noteStats = {};
  const incoming = dc.useQuery(
    `@page and exists(in) and contains(in, link([[Maps]])) and !path("x/Templates")`
  );
  incoming.forEach((page) => {
    const innerPath = page.$path;

    const innerIncoming = dc.useQuery(
      `@page and exists(in) and contains(in, link("${innerPath}")) and !path("x/Templates")`
    );

    noteStats[innerPath] = {
      backlinks: innerIncoming?.length ?? 0,
      totalLinks: page.$links?.length + innerIncoming?.length ?? 0,
    };
  });

  const COLUMNS = [
    { id: "Map", value: (page) => page.$link },
    { id: "Total Links", value: (page) => noteStats[page.$path]?.totalLinks },
    { id: "Backlinks", value: (page) => noteStats[page.$path]?.backlinks },
    { id: "Outgoing Links", value: (page) => page.value("$links")?.length },
  ];

  // const pages = incoming.concat(outgoing);

  const pages = dc.useQuery(
    `@page and exists(in) and contains(in, link([[Maps]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort((a, b) => {
        const aTotalLinks = noteStats[a.$path]?.totalLinks || 0;
        const bTotalLinks = noteStats[b.$path]?.totalLinks || 0;
        return bTotalLinks - aTotalLinks;
      }),
    [pages, noteStats]
  );

  return <dc.VanillaTable columns={COLUMNS} rows={sortedPages} paging={true} />;
}

function AllMapsByRankQuery() {
  const columns = [
    { id: "Map", value: (page) => page.$link },
    { id: "Rank", value: (page) => page.value("rank") },
    { id: "State", value: (page) => page.value("mapState")?.join() },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Maps]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rank", sortOrder: "desc", type: "number" },
          { fieldName: "$name", sortOrder: "asc", type: "string" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllMapsByStateQuery() {
  const columns = [
    { id: "Map", value: (page) => page.$link },
    { id: "Collection", value: (page) => page.value("in")?.join(", ") },
    { id: "State", value: (page) => page.value("mapState")?.join() },
    { id: "Rank", value: (page) => page.value("rank") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Maps]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort(
          [
            { fieldName: "mapState", sortOrder: "asc", type: "custom" },
            { fieldName: "rank", sortOrder: "desc", type: "number" },
          ],
          { mapState: ["🟥", "🟨", "🟩"] }
        )
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllCollectionsQuery() {
  const columns = [
    { id: "Collections", value: (page) => page.$link },
    { id: "Rank", value: (page) => page.value("rank") },
    { id: "State", value: (page) => page.value("mapState")?.join() },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Collections]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort(
          [
            { fieldName: "rank", sortOrder: "desc", type: "number" },
            { fieldName: "mapState", sortOrder: "asc", type: "custom" },
            { fieldName: "$name", sortOrder: "asc", type: "string" },
          ],
          { mapState: ["🟥", "🟨", "🟩"] }
        )
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function AllViewsQuery() {
  const columns = [
    { id: "Map views", value: (page) => page.$link },
    { id: "Rank", value: (page) => page.value("rank") },
    { id: "State", value: (page) => page.value("mapState")?.join() },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Views]])) and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rank", sortOrder: "desc", type: "number" },
          { fieldName: "$name", sortOrder: "asc", type: "string" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

function FavoriteSensemakingMapsQuery() {
  const columns = [
    { id: "", value: (page) => page.$link },
    { id: "Rank", value: (page) => page.value("rank") },
    { id: "State", value: (page) => page.value("mapState")?.join() },
    { id: "Collection", value: (page) => page.value("in")?.join(", ") },
  ];

  const pages = dc.useQuery(
    `@page and contains(in, link([[Maps]])) and !contains(in, link([[Collections]])) and rank > 3.5 and !path("x/Templates")`
  );

  const sortedPages = dc.useMemo(
    () =>
      pages.sort(
        multiSort([
          { fieldName: "rank", sortOrder: "desc", type: "number" },
          { fieldName: "$name", sortOrder: "asc", type: "string" },
        ])
      ),
    [pages]
  );

  return <dc.VanillaTable columns={columns} rows={sortedPages} paging={true} />;
}

return {
  AllMapsByTotalLinksQuery,
  AllCollectionsQuery,
  AllViewsQuery,
  AllMapsByStateQuery,
  AllMapsByRankQuery,
  FavoriteSensemakingMapsQuery,
};
