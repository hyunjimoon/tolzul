# 04-Method-6_StatPower_Scaling

(이 문단의 역할: 실증 방법(측정·식별·사양·로버스트·스케일링))

• 효과크기 해석, 샘플 사이즈/검정력, 다중가설 보정 계획.
---

Prev: [[21-Method-5_RobustnessPlan]]  
Next: [[23-Results-1_EarlyFundingPenalty]]


> 자동 생성: 2025-11-16T07:55:35
