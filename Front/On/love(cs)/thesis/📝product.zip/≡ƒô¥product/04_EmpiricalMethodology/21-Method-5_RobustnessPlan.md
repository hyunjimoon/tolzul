# 04-Method-5_RobustnessPlan

(이 문단의 역할: 실증 방법(측정·식별·사양·로버스트·스케일링))

• 대체 측정(사전/임계/가중식), 표본 제한, 시간창, 사양커브, 민감도.
---

Prev: [[20-Method-4_MainSpecs]]  
Next: [[22-Method-6_StatPower_Scaling]]


> 자동 생성: 2025-11-16T07:55:35
