# 04-Method-3_Identification_Strategy

(이 문단의 역할: 실증 방법(측정·식별·사양·로버스트·스케일링))

• 오염원 → 대응 → 검증(사전추세, 고정효과, 코호트 추적, 플라시보/퍼뮤테이션/사양커브).
• IV 미사용 원칙을 명시하고 대조점으로 관련 문헌의 구조만 언급.
---

Prev: [[18-Method-2_DescriptiveStats]]  
Next: [[20-Method-4_MainSpecs]]


> 자동 생성: 2025-11-16T07:55:35
