---
modified:
  - 2025-11-16T08:17:20-05:00
---
# 04-Method-4_MainSpecs

(이 문단의 역할: 실증 방법(측정·식별·사양·로버스트·스케일링))

• Model A: OLS `E ~ V + …`
• Model B: Logit `Pr(L=1) ~ V × F + E + …`
• Model C: 보조(지속기간/생존). 표준오류/클러스터링 규칙.
---

Prev: [[19-Method-3_Identification_Strategy]]  
Next: [[21-Method-5_RobustnessPlan]]


> 자동 생성: 2025-11-16T07:55:35

