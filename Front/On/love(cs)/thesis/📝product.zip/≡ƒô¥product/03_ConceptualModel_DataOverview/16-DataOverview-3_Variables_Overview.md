# 03-DataOverview-3_Variables_Overview

(이 문단의 역할: 데이터 맥락·표본·변수 개요)

• 핵심 변수 정의/단위/직관: `E, L, S, V, F`.
• `V`는 *(i) 범주적 모호어(S_cat), (ii) 구체성 결핍(S_concdef)* 합성지수(0–100→[0,1]).
• `V_pct`는 경험적 CDF 기반 퍼센타일 변환(상호작용/시각화 보조).
---

Prev: [[15-DataOverview-2_Sample_Construct]]  
Next: [[17-Method-1_Measurements]]


> 자동 생성: 2025-11-16T07:55:35
