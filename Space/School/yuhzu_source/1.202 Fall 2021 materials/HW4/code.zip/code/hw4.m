B=-213*140/450.*[-log(213/97), log(140/97); log(140/97), -log(140/97)]
invB = inv(B)
sqrtinvB = sqrt(invB)